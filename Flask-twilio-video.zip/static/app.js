function addLocalVideo()
{
	Twilio.Video.createLocalVideotravk().then(track => {
		let video = document.getElementById('local').firstChild;
		video.appendChild(track.attach());
	});
};

addLocalVideo();